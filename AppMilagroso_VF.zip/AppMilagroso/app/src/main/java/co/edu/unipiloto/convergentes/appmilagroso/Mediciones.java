package co.edu.unipiloto.convergentes.appmilagroso;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class Mediciones {

    private List<String> diabetes = new ArrayList<>();
    private List<String> hipertension = new ArrayList<>();
    private List<String> insuCardiaca = new ArrayList<>();

    public Mediciones(){
        diabetes.add("glucosa");
        diabetes.add("agudeza visual");
        hipertension.add("presión arterial");
        insuCardiaca.add("frecuencia cardiaca");
    }

    public List<String> getMediciones(String enfermedad){
        if (enfermedad.equals("Diabetes")){
            return diabetes;
        } else if (enfermedad.equals("Hipertension")) {
            return hipertension;
        }else {
            return insuCardiaca;
        }
    }
}
