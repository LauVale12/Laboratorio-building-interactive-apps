package co.edu.unipiloto.convergentes.beeradviser;

import java.util.List;

public class BeerExpert {

    private List<String> cervezaslight;
    private List<String> cervezasamber;
    private List<String> cervezasbrown;
    private List<String> cervezasdark;
    
    
    public BeerExpert(){
       cervezaslight.add("Aguila light");
        cervezaslight.add("Andina light");
        cervezasamber.add("Moonshine amber ale");
        cervezasamber.add("Mulata 3 cordilleras");
        cervezasbrown.add("Dobeerman brown ale");
        cervezasbrown.add("Colón Brown ale");
        cervezasdark.add("Club colombia negra");
        cervezasdark.add("Delirium nocturnum");
    }
    
    public List<String> getBrands(String color){
        if(color.equals("light")){
            return cervezaslight;
        }else if (color.equals("amber")){
            return cervezasamber;
        } else if (color.equals("brown")) {
            return cervezasbrown;
        }else {
            return cervezasdark;
        }
    }
}
