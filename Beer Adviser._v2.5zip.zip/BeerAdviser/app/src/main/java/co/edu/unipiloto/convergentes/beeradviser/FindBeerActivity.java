package co.edu.unipiloto.convergentes.beeradviser;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.List;

public class FindBeerActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_beer);
    }

    //Called when the button gets clicked
    public void onClickFindBeer(View view){
        //Get a reference to the TextView
        TextView brands = (TextView)findViewById(R.id.brands);
        //Get a reference to the Spinner
        Spinner color = (Spinner) findViewById(R.id.color);
        //Get selected item in the Spinner
        String beerType = String.valueOf(color.getSelectedItem());
        //Display the selected item
        //brands.setText(beerType);

        //Llamar al metodo de BeerExpert
        BeerExpert beerExpert = new BeerExpert();
        List<String> list = beerExpert.getBrands(beerType);
        //Recorrer la lista
        String ejemplos ="";
        for(String str: list){
            ejemplos += str + " y ";
        }

        //Mostrar las cervezas del tipo seleccionado
        brands.setText(ejemplos);
    }
}