package co.edu.unipiloto.convergentes.appmilagroso;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onClickFindPatient(View view){
        TextView nombre = (TextView) findViewById(R.id.nombre);
        Spinner tipo_paciente = (Spinner) findViewById(R.id.tipo_paciente);
        String paciente = String.valueOf(tipo_paciente.getSelectedItem());
        nombre.setText(paciente);
    }
}